// Generated from mobile-shell-types/src/native.rs. Do not edit.
import Foundation

let nativeBridgeVersion: UInt32 = 6
let nativeBackSurfaceVersion: UInt32 = 1

let nativeShellRelease = "0.9.6-beta.29"
let nativeBootstrapVersion: UInt32 = 1

enum NativeTab: String, Codable, Hashable {
    case home = "home"
    case agents = "agents"
    case sessions = "sessions"
    case settings = "settings"
}

enum NativeRoute: String, Codable, Hashable {
    case root = "root"
    case chat = "chat"
    case hosts = "hosts"
}

enum NativeLayout: String, Codable, Hashable {
    case compact = "compact"
    case regular_portrait = "regular_portrait"
    case regular_landscape = "regular_landscape"
}

enum NativeTheme: String, Codable, Hashable {
    case dark = "dark"
    case light = "light"
}

enum NativeChatHeaderOwner: String, Codable, Hashable {
    case shell = "shell"
    case client = "client"
}

enum NativeRootStatusOwner: String, Codable, Hashable {
    case shell = "shell"
}

struct NativeConnectedStatus: Codable {
    let round_trip_ms: UInt64?
}

enum NativeBackPhase: String, Codable, Hashable {
    case progress = "progress"
    case cancel = "cancel"
    case complete = "complete"
}

struct NativeBackUpdate: Codable {
    let version: UInt32
    let phase: NativeBackPhase
    let source_revision: UInt64
    let progress: UInt32
}

struct NativeBackDestination: Codable {
    let tab: NativeTab
    let route: NativeRoute
    let title: String
}

enum NativeIntent: String, Codable, Hashable {
    case home = "home"
    case agents = "agents"
    case sessions = "sessions"
    case settings = "settings"
    case back = "back"
    case hosts = "hosts"
    case new_chat = "new_chat"
    case rename_agent = "rename_agent"
    case send_actions = "send_actions"
    case session_settings = "session_settings"
    case close_agent = "close_agent"
    case regular_width = "regular_width"
    case compact_width = "compact_width"
    case regular_landscape = "regular_landscape"
    case toggle_sidebar = "toggle_sidebar"
    case foreground = "foreground"
    case background = "background"
}

enum NativeEndpoint: String, Codable, Hashable {
    case presentation = "presentation"
    case http = "http"
    case http_cancel = "http_cancel"
    case authenticate = "authenticate"
    case secret_scope = "secret_scope"
    case secret_read = "secret_read"
    case secret_write = "secret_write"
    case secret_delete = "secret_delete"
}

enum NativeHttpMethod: String, Codable, Hashable {
    case get = "get"
    case post = "post"
}

enum NativeAuthProvider: String, Codable, Hashable {
    case apple = "apple"
    case google = "google"
}

struct NativePresentation: Codable {
    let version: UInt32
    let client_ready: Bool
    let workspace: Bool
    let tab: NativeTab
    let route: NativeRoute
    let title: String
    let subtitle: String?
    let chat_actions: Bool
    let modal: Bool
    let theme: NativeTheme
    let sidebar_available: Bool
    let sidebar_open: Bool
    let chat_header_owner: NativeChatHeaderOwner?
    let root_status_owner: NativeRootStatusOwner?
    let root_connected_status: NativeConnectedStatus?
    let back_surface_version: UInt32?
    let navigation_revision: UInt64?
    let back_ready_revision: UInt64?
    let back_destination: NativeBackDestination?
}

struct NativeHttpRequest: Codable {
    let id: UInt32
    let url: String
    let method: NativeHttpMethod
    let body: String?
    let headers: [String: String]
}

struct NativeHttpCancel: Codable {
    let id: UInt32
}

struct NativeHttpResponse: Codable {
    let status: UInt16
    let body: String
}

struct NativeSecretKey: Codable {
    let key: String
}

struct NativeSecretScope: Codable {
    let keys: [String]
}

struct NativeSecretWrite: Codable {
    let key: String
    let value: String
}

struct NativeAuthRequest: Codable {
    let provider: NativeAuthProvider
}


#if !DEBUG
#error("QA bootstrap resources require a Debug build")
#endif

let nativeBootstrapOrigin = "https://qa-nativeback-live-20261106.tycode.dev"
